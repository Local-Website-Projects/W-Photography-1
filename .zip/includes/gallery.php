<!-- start wpo-portfolio-section -->
<section class="wpo-portfolio-section-s2 section-padding" id="gallery">
    <div class="container">
        <div class="wpo-section-title">
            <h4>Sweet Memories</h4>
            <h2>Our Captured Moments</h2>
        </div>
        <div class="sortable-gallery">
            <div class="gallery-filters"></div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="portfolio-grids gallery-container clearfix">
                        <div class="grid">
                            <div class="img-holder">
                                <a href="assets/images/portfolio/10.jpg" class="fancybox"
                                   data-fancybox-group="gall-1">
                                    <img src="assets/images/portfolio/10.jpg" alt class="img img-responsive">
                                    <div class="hover-content">
                                        <i class="ti-plus"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="img-holder">
                                <a href="assets/images/portfolio/5.jpg" class="fancybox"
                                   data-fancybox-group="gall-1">
                                    <img src="assets/images/portfolio/5.jpg" alt class="img img-responsive">
                                    <div class="hover-content">
                                        <i class="ti-plus"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="img-holder">
                                <a href="assets/images/portfolio/6.jpg" class="fancybox"
                                   data-fancybox-group="gall-1">
                                    <img src="assets/images/portfolio/6.jpg" alt class="img img-responsive">
                                    <div class="hover-content">
                                        <i class="ti-plus"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="img-holder">
                                <a href="assets/images/portfolio/7.jpg" class="fancybox"
                                   data-fancybox-group="gall-1">
                                    <img src="assets/images/portfolio/7.jpg" alt class="img img-responsive">
                                    <div class="hover-content">
                                        <i class="ti-plus"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="img-holder">
                                <a href="assets/images/portfolio/8.jpg" class="fancybox"
                                   data-fancybox-group="gall-1">
                                    <img src="assets/images/portfolio/8.jpg" alt class="img img-responsive">
                                    <div class="hover-content">
                                        <i class="ti-plus"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="img-holder">
                                <a href="assets/images/portfolio/9.jpg" class="fancybox"
                                   data-fancybox-group="gall-1">
                                    <img src="assets/images/portfolio/9.jpg" alt class="img img-responsive">
                                    <div class="hover-content">
                                        <i class="ti-plus"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="grid">
                            <div class="img-holder">
                                <a href="assets/images/portfolio/11.jpg" class="fancybox"
                                   data-fancybox-group="gall-1">
                                    <img src="assets/images/portfolio/11.jpg" alt class="img img-responsive">
                                    <div class="hover-content">
                                        <i class="ti-plus"></i>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- end container -->
</section>
<!-- end wpo-portfolio-section -->