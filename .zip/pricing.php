<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="wpOceans">
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">
    <title> Photography Template - FrogBID </title>
    <?php include ('includes/css.php');?>
</head>

<body>

<!-- start page-wrapper -->
<div class="page-wrapper">
    <!-- start preloader -->
    <?php include ('includes/preloader.php');?>
    <!-- end preloader -->

    <!-- Start header -->
    <?php include ('includes/inner_header.php');?>
    <!-- end of header -->

    <!-- start wpo-page-title -->
    <section class="wpo-page-title" style="margin-bottom: 100px;">
        <div class="container">
            <div class="row">
                <div class="col col-xs-12">
                    <div class="wpo-breadcumb-wrap">
                        <h2>Pricing</h2>
                        <ol class="wpo-breadcumb-wrap">
                            <li><a href="Home">Home</a></li>
                            <li>Pricing</li>
                        </ol>
                    </div>
                </div>
            </div> <!-- end row -->
        </div> <!-- end container -->
    </section>
    <!-- end page-title -->

    <!-- start wpo-pricing-section -->
    <?php include ('includes/pricing.php');?>
    <!-- start wpo-pricing-section -->

    <!-- start wpo-partners-section -->
    <section class="wpo-partners-section section-padding">
        <h2 class="hidden">Partners</h2>
        <div class="container">
            <div class="row">
                <div class="col col-xs-12">
                    <div class="partner-grids partners-slider owl-carousel">
                        <div class="grid">
                            <img src="assets/images/partners/1.png" alt>
                        </div>
                        <div class="grid">
                            <img src="assets/images/partners/2.png" alt>
                        </div>
                        <div class="grid">
                            <img src="assets/images/partners/3.png" alt>
                        </div>
                        <div class="grid">
                            <img src="assets/images/partners/4.png" alt>
                        </div>
                        <div class="grid">
                            <img src="assets/images/partners/5.png" alt>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- end container -->
    </section>
    <!-- end wpo-partners-section-->

    <!-- wpo-site-footer start -->
    <?php include ('includes/footer.php');?>
    <!-- wpo-site-footer end -->


</div>
<!-- end of page-wrapper -->

<!-- All JavaScript files
================================================== -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- Plugins for this template -->
<script src="assets/js/modernizr.custom.js"></script>
<script src="assets/js/jquery.dlmenu.js"></script>
<script src="assets/js/jquery-plugin-collection.js"></script>
<!-- Custom script for this template -->
<script src="assets/js/script.js"></script>
</body>

</html>